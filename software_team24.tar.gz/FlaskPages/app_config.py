#!/usr/bin/env python

"""
Application configurations

TOP SECRET
NEVER CHECK IN THE FILE IN GIT REPOSITORY
"""

app_secret_key = "\xa3\xbb\x90'\x8e*\xbc}\x98\x9b\xaed\xe7\x99\x1d+\x8f6\xc7\xae\x8aR\x17\xba"

